# ESTREMOZ ALERTA — projeto Android

Aplicação fictícia para o servidor Estremoz Roleplay. Esta pasta contém o código-fonte para gerar um projeto Android com Capacitor. **Não é ainda um APK/AAB pronto para instalar ou publicar.**

## 1. Requisitos
- Computador Windows, macOS ou Linux
- Node.js LTS e npm
- Android Studio e Android SDK
- Conta Google Play Console para publicar na Play Store
- Projeto Firebase para partilhar ocorrências entre utilizadores

## 2. Preparar a base de dados partilhada (Firebase)
1. Cria um projeto em https://console.firebase.google.com/
2. Adiciona uma aplicação Web e copia a configuração Firebase.
3. Ativa Authentication > Sign-in method > Anonymous.
4. Cria uma Firestore Database.
5. Substitui os valores `COLOCA_AQUI` em `www/app.js` pela configuração real.
6. Em Firestore Rules, usa regras que exijam autenticação. Exemplo inicial para testes:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /incidents/{incidentId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null
        && request.resource.data.kind is string
        && request.resource.data.place is string
        && request.resource.data.description is string;
      allow update: if request.auth != null
        && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['status']);
      allow delete: if false;
    }
  }
}

Estas regras são um ponto de partida, não uma configuração anti-abuso completa. Para uma aplicação pública, acrescenta Firebase App Check, limites de publicação, validação de campos e moderação. A autenticação anónima não confirma a identidade de quem publica.

## 3. Gerar a aplicação Android
Na pasta do projeto, abre um terminal e executa:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio:
1. Espera pela sincronização do Gradle.
2. Testa em emulador ou telemóvel Android.
3. Para criar o pacote da Play Store, escolhe **Build > Generate Signed Bundle / APK**.
4. Escolhe **Android App Bundle (AAB)** e cria/guarda a chave de assinatura num local seguro.
5. Testa o AAB e prepara a ficha da aplicação na Play Console.

## 4. Antes da publicação
- Substitui o símbolo provisório “EA” pelo logótipo oficial apenas se tiveres autorização para o utilizar.
- Acrescenta política de privacidade e contacto de suporte.
- Preenche a classificação etária e a declaração de segurança de dados.
- Confirma os requisitos de versão Android/target API em vigor na Play Console.
- Não publiques dados pessoais, moradas privadas ou informações reais de emergências.

## Aviso
Esta app é exclusivamente para Roleplay. Não é oficial dos Bombeiros Voluntários de Estremoz nem de qualquer entidade de emergência. Não usar para alertar serviços reais. Em Portugal, emergências reais devem ser comunicadas ao 112.
