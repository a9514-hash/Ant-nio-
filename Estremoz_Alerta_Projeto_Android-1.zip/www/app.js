import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, updateDoc, doc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

// 1) Cria um projeto em https://console.firebase.google.com/
// 2) Ativa Authentication > Sign-in method > Anonymous.
// 3) Cria Firestore Database e cola aqui a configuração da tua aplicação Web.
const firebaseConfig = {
  apiKey: "COLOCA_AQUI_A_API_KEY",
  authDomain: "COLOCA_AQUI.firebaseapp.com",
  projectId: "COLOCA_AQUI",
  storageBucket: "COLOCA_AQUI.firebasestorage.app",
  messagingSenderId: "COLOCA_AQUI",
  appId: "COLOCA_AQUI"
};
const configured = !Object.values(firebaseConfig).some(v => String(v).includes("COLOCA_AQUI"));
let db=null, currentFilter="Todas", records=[];
const $=id=>document.getElementById(id);
function escapeHTML(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function card(x){
 const done=x.status==="Resolvida";
 return `<article class="card"><div class="cardtop"><span class="meta">OCORRÊNCIA #${escapeHTML(x.code||"—")} · ${escapeHTML(x.timeLabel||"")}</span><span class="pill ${done?"done":x.priority==="Crítica"?"critical":""}">${escapeHTML(x.status||"Em curso")}</span></div><h3>${escapeHTML(x.kind)}</h3><div class="meta">📍 ${escapeHTML(x.place)}</div><p>${escapeHTML(x.description)}</p><div class="meta">🚒 ${escapeHTML(x.units||"Meios não indicados")} · ${escapeHTML(x.author||"Utilizador")}</div>${!done?`<button class="filter" style="background:#187044;margin-top:10px" data-resolve="${escapeHTML(x.id)}">Marcar resolvida</button>`:""}</article>`;
}
function render(){
 const active=records.filter(x=>x.status!=="Resolvida").length;
 $("activeCount").textContent=active;$("resolvedCount").textContent=records.length-active;$("totalCount").textContent=records.length;
 $("recent").innerHTML=records.slice(0,3).map(card).join("")||'<p class="muted">Ainda não existem ocorrências.</p>';
 const shown=currentFilter==="Todas"?records:records.filter(x=>x.status===currentFilter);
 $("allIncidents").innerHTML=shown.map(card).join("")||'<p class="muted">Sem ocorrências nesta categoria.</p>';
}
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>{
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x===b));
 document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===b.dataset.page));
}));
document.querySelectorAll(".filter[data-filter]").forEach(b=>b.addEventListener("click",()=>{
 currentFilter=b.dataset.filter;document.querySelectorAll(".filter[data-filter]").forEach(x=>x.classList.toggle("active",x===b));render();
}));
document.addEventListener("click",async e=>{
 const id=e.target.dataset.resolve;if(!id)return;
 if(!db){alert("Configura primeiro a ligação Firebase.");return;}
 try{await updateDoc(doc(db,"incidents",id),{status:"Resolvida"});}catch(err){alert("Não foi possível atualizar: "+err.message);}
});
$("incidentForm").addEventListener("submit",async e=>{
 e.preventDefault();$("formMessage").textContent="";
 if(!db){$("formMessage").textContent="A app ainda não está ligada à base de dados. Segue o README para configurar o Firebase.";return;}
 const data={kind:$("kind").value,place:$("place").value.trim(),description:$("description").value.trim(),units:$("units").value.trim(),priority:$("priority").value,author:$("author").value.trim()||"Utilizador",status:"Em curso",createdAt:serverTimestamp(),timeLabel:new Date().toLocaleString("pt-PT"),code:String(Date.now()).slice(-6)};
 try{await addDoc(collection(db,"incidents"),data);e.target.reset();$("formMessage").textContent="Ocorrência publicada com sucesso.";document.querySelector('[data-page="incidents"]').click();}
 catch(err){$("formMessage").textContent="Erro ao publicar. Verifica a configuração e as regras Firebase.";}
});
if(configured){
 try{
  const app=initializeApp(firebaseConfig);const auth=getAuth(app);db=getFirestore(app);
  await signInAnonymously(auth);
  onSnapshot(query(collection(db,"incidents"),orderBy("createdAt","desc")),snap=>{
   records=snap.docs.map(d=>({id:d.id,...d.data()}));render();
  },err=>{$("recent").textContent="Erro ao carregar dados: "+err.message;});
 }catch(err){$("recent").textContent="Falha na ligação Firebase. Confirma a configuração.";console.error(err);}
}else{
 records=[
 {id:"demo1",code:"000101",kind:"Incêndio em veículo",place:"Centro de Estremoz",description:"Exemplo de ocorrência fictícia.",units:"2 veículos · 2 operacionais",priority:"Alta",status:"Em curso",timeLabel:"Exemplo"},
 {id:"demo2",code:"000102",kind:"Acidente rodoviário",place:"EN4 — Estremoz",description:"Exemplo de ocorrência resolvida.",units:"1 veículo · 3 operacionais",priority:"Média",status:"Resolvida",timeLabel:"Exemplo"}
 ];render();
 $("formMessage").textContent="Modo demonstração: configura Firebase para partilhar ocorrências entre telemóveis.";
}
